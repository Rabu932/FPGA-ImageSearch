the input parameter for memcached pipeline HLS simulation should be:

../../../../../hls/pkt.in.txt    ../../../../../hls/pkt.out.txt
