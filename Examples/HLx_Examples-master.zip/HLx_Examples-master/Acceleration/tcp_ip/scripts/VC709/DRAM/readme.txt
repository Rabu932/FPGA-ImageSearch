To create dual channel migh with AXI_MM interface, please follow the steps below:
	1. create a Vivado project with vivado 2016.2 (other Vivado version might work as well)
	2. In the project setting, choose VC709 evaluation board
	3. In the Vivado TCL console run command "source genMigDual2016_2.tcl"
